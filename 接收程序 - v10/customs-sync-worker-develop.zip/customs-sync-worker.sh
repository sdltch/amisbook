java -cp .:amiintellect-customs-sync-worker-1.0.jar:lib/* com.amiintellect.customs.sync.worker.App &
